Submitted by:
Ido Michael-201157138
Dana Erlich-200400950


Exercise 6
==========

Submission includes the following:
+ runnnable jar - ex6.jar
+ source file jar - ex6-src.jar

SolarSystem:
When running executable jar, our bitmap folder must be included so that the jar runs because we used a background texture 
(which is included in the bitmap folder).
We implemented the solar system with the correction in the tilt and using the given data.
Durration of self revolution was set according to given data.
Orbital periods were also set according to the given data.

Irenderable:
render was changed to require a boolean indicating if axis should be on or off. 

Light
The scene includes a red light and a white light.

No additional Models 