Submitted by:
Ido Michael-201157138
Dana Erlich-200400950


Exercise 5
==========

Submission includes the following:
+ runnnable jar - ex5.jar
+ java source files

Irenderable:
render was changed to require a boolean indicating if axis should be on or off. 

The Solar System:
The planets are shifted to some arbitrary initial positions on their orbits so that they form a spiral.
We implemented the solar system with the correction in the tilt and using the given data.

Light
The scene includes a red light and a white light.

No additional Models 